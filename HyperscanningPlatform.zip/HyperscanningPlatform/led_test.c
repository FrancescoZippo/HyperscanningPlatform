#include "lsl_c.h"
#include <sys/time.h>
#include <unistd.h>
#include <bcm2835.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define PIN_GLED    RPI_V2_GPIO_P1_18
#define PIN_RLED    RPI_V2_GPIO_P1_22

int main()
{
	int i=0;
	int flag=0;
	
	//Initialise GPIO pins
		printf("Initiating BCM2835...\n");
	if (!bcm2835_init())
	{
		printf("Initiation failed. Are you running as root?\n");
		return 1;
	}
	printf("BCM2835 initiated!\n");
	
	//Pins for GPIO	
	bcm2835_gpio_fsel(PIN_RLED , BCM2835_GPIO_FSEL_OUTP);
	bcm2835_gpio_fsel(PIN_GLED , BCM2835_GPIO_FSEL_OUTP);

	// test LEDs
	bcm2835_gpio_write(PIN_RLED , HIGH);
	bcm2835_gpio_write(PIN_GLED , HIGH);
	sleep(3);
	while(1){
	bcm2835_gpio_write(PIN_RLED , HIGH);
	bcm2835_gpio_write(PIN_GLED , HIGH);
	bcm2835_delay(5000);
	bcm2835_gpio_write(PIN_RLED , LOW);
	bcm2835_gpio_write(PIN_GLED , LOW);
	i++;
	}
        printf("Closing BCM2835\n\n");
        bcm2835_close();
        return 0;

}


